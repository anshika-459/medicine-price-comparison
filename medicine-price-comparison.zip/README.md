# Medicine Price Comparison & Alternative Finder

A Python + MySQL student project that stores medicine information and lets a user:
- Search by medicine name, ingredient, or use
- Compare stored medicines containing the same ingredient
- Sort alternatives by price

## Tech Stack
- Python
- MySQL
- Object-Oriented Programming
- SQL

## Setup
1. Install MySQL and create a database using `schema.sql`.
2. Create a Python environment.
3. Run `pip install -r requirements.txt`.
4. Open `app.py` and replace `YOUR_MYSQL_PASSWORD`.
5. Run `python app.py`.

## Note
This is an educational database project. It is not a medical recommendation system and should not be used to choose medication.