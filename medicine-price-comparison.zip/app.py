import mysql.connector
from dataclasses import dataclass

@dataclass
class Medicine:
    name: str
    salt: str
    price: float
    uses: str

class MedicineFinder:
    def __init__(self, db_config):
        self.db_config = db_config

    def connection(self):
        return mysql.connector.connect(**self.db_config)

    def search(self, keyword):
        conn = self.connection()
        cur = conn.cursor(dictionary=True)
        cur.execute("""
            SELECT name, salt, price, uses
            FROM medicines
            WHERE name LIKE %s OR salt LIKE %s OR uses LIKE %s
            ORDER BY name
        """, (f"%{keyword}%", f"%{keyword}%", f"%{keyword}%"))
        rows = cur.fetchall()
        cur.close()
        conn.close()
        return [Medicine(**row) for row in rows]

    def compare(self, salt):
        conn = self.connection()
        cur = conn.cursor(dictionary=True)
        cur.execute("""
            SELECT name, salt, price, uses
            FROM medicines
            WHERE salt LIKE %s
            ORDER BY price ASC
        """, (f"%{salt}%",))
        rows = cur.fetchall()
        cur.close()
        conn.close()
        return [Medicine(**row) for row in rows]

def print_results(items):
    if not items:
        print("\nNo medicines found.")
        return
    print("\nName | Salt/Ingredient | Price | Uses")
    print("-" * 80)
    for m in items:
        print(f"{m.name} | {m.salt} | Rs.{m.price:.2f} | {m.uses}")

def main():
    print("Medicine Price Comparison & Alternative Finder")
    print("Use only as a student database project; it does not provide medical advice.\n")

    config = {
        "host": "localhost",
        "user": "root",
        "password": "YOUR_MYSQL_PASSWORD",
        "database": "medicine_db"
    }
    finder = MedicineFinder(config)

    while True:
        print("\n1. Search medicine")
        print("2. Find alternatives by salt/ingredient")
        print("3. Exit")
        choice = input("Choose: ").strip()

        try:
            if choice == "1":
                print_results(finder.search(input("Medicine/keyword: ").strip()))
            elif choice == "2":
                print_results(finder.compare(input("Salt/ingredient: ").strip()))
            elif choice == "3":
                break
            else:
                print("Invalid choice.")
        except mysql.connector.Error as e:
            print("Database error:", e)

if __name__ == "__main__":
    main()