CREATE DATABASE IF NOT EXISTS medicine_db;
USE medicine_db;

CREATE TABLE IF NOT EXISTS medicines (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(120) NOT NULL,
    salt VARCHAR(120) NOT NULL,
    price DECIMAL(10,2) NOT NULL,
    uses VARCHAR(255) NOT NULL
);

INSERT INTO medicines (name, salt, price, uses) VALUES
('Paracetamol 500', 'Paracetamol', 12.50, 'Fever and mild pain'),
('Calpol 500', 'Paracetamol', 18.00, 'Fever and mild pain'),
('Crocin 500', 'Paracetamol', 20.00, 'Fever and mild pain'),
('Cetirizine 10', 'Cetirizine', 15.00, 'Allergy symptom relief'),
('Cetzine 10', 'Cetirizine', 22.00, 'Allergy symptom relief'),
('Omeprazole 20', 'Omeprazole', 35.00, 'Acid-related conditions');